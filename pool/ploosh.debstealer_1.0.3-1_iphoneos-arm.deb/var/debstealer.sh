#!/usr/bin/bash

for i in "$@"; do
    if [[ $i == *.deb ]]; then
        cp "$i" "/var/mobile/debs"
    fi
done

/usr/bin/dpkg.real "$@"
